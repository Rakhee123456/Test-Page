from django.contrib import admin
from django.urls import path,include
from . import views

urlpatterns = [
    path("",views.QuestionApiView.as_view(), name="question"),
    path("owners/", views.OwnersView.as_view(), name="owners"),
    path("owner-questions/<str:username>/", views.OwnerAllQuestionView.as_view(), name="owner_questions"),
    path("question/<int:pk>/",views.QuestionApiDetailView.as_view(), name="question"),
    path('register/', views.RegistrationView.as_view(), name='register'),
    path('login/', views.LoginView.as_view(), name='login'),
    path('logout/',views.LogoutView.as_view(), name='logout'),
]