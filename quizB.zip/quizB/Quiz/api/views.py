from django.shortcuts import render,HttpResponse
from django.contrib.auth import authenticate,login,logout
from .models import CustomUser,Question
from rest_framework.views import APIView   
from .serializers import CustomUserSerializer,CustomUserLoginSerializer, QuestionSerializer, UserWithQuestionCountSerializer
from django.contrib.auth.models import Group 
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated   
from rest_framework import status
from rest_framework_simplejwt.tokens import RefreshToken  
from .renderers import UserRenderer 
from rest_framework.exceptions import NotFound
# Create your views here.
def get_tokens_for_user(user):
    refersh = RefreshToken.for_user(user)
    return{
        'refresh':str(refersh),
        'access':str(refersh.access_token)
    }
    
class HomeView(APIView):
    def get(self, request):
        return Response("hello world", status=status.HTTP_200_OK)  
    
    
class RegistrationView(APIView):
    renderer_classes = [UserRenderer]
    
    def get(self, request):
        try:
            users = CustomUser.objects.all()
            serializer = CustomUserSerializer(users, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST)

    def post(self, request):
        data = request.data
        serializer = CustomUserSerializer(data=data)
        
        if serializer.is_valid():
            try:
                user = serializer.save()
                if user.is_player: 
                    self._assign_group(user, 'player')
                    token = self._generate_token_for_user(user) 
                
                else:
                    self._assign_group(user, 'owner')
                    token = self._generate_token_for_user(user)
                
                message = {
                    'message': 'User created successfully',
                    'user': serializer.data,
                    'token': token
                }
                return Response(message, status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response(str(e), status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    def _assign_group(self, user, group_name):
        """Assign a user to a specific group."""
        group = Group.objects.get(name=group_name)
        user.groups.add(group)
        
    def _generate_token_for_user(self, user):
        """Generate JWT token for a user."""
        return get_tokens_for_user(user)   
             
class LoginView(APIView):
    def get(self,request):
        return Response({"message": "This is a GET Login request"}, status=status.HTTP_200_OK)    
    
    def post(self, request):
        try:
            serializer = CustomUserLoginSerializer(data=request.data)
            if serializer.is_valid():
                username = serializer.validated_data['username']
                password = serializer.validated_data['password']
                user = authenticate(username=username, password=password)
                user = CustomUser.objects.get(username=username)
                if user:
                    login(request, user)
                    token = get_tokens_for_user(user)   
                    
                    message = {
                        'message': 'User logged in successfully',
                        'user': CustomUserSerializer(user).data,
                        'token': token
                    }
                    return Response(message, status=status.HTTP_200_OK)
           
            else:
                if 'non_field_errors' in serializer.errors:
                    return Response(serializer.errors['non_field_errors'], status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST) 
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        
class LogoutView(APIView):
    def get(self,request):
        try:
            user = logout(request)
            print("user",user)  
            message = {
                'message': 'User logged out successfully',
                'user':user    

            }
            return Response(message, status=status.HTTP_200_OK)
        except Exception as e:
            return Response(str(e), status=status.HTTP_400_BAD_REQUEST)


class QuestionApiView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        user = request.user
        questions = Question.objects.filter(user=user)
        serializer = QuestionSerializer(questions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    
    def post(self, request, *args, **kwargs):
        data = request.data
        serializer = QuestionSerializer(data=data, context={'request': request})
        
        if serializer.is_valid():
            try:
                question = serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            except Exception as e:
                return Response({"detail": str(e)}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)



class QuestionApiDetailView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, pk=None):
        if pk:
            try:
                question = Question.objects.get(pk=pk, user=request.user)
                serializer = QuestionSerializer(question)
                return Response(serializer.data, status=status.HTTP_200_OK)
            except Question.DoesNotExist:
                raise NotFound("Question not found or not accessible by the user")
        else:
            questions = Question.objects.filter(user=request.user)
            serializer = QuestionSerializer(questions, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

    def put(self, request, pk=None):
        try:
            question = Question.objects.get(pk=pk, user=request.user)
        except Question.DoesNotExist:
            raise NotFound("Question not found or not accessible by the user")
        
        serializer = QuestionSerializer(question, data=request.data, partial=True, context={'request': request})
        
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk=None):
        try:
            question = Question.objects.get(pk=pk, user=request.user)
            question.delete()
            return Response(status=status.HTTP_204_NO_CONTENT)
        except Question.DoesNotExist:
            raise NotFound("Question not found or not accessible by the user")
         

class OwnersView(APIView):
    def get(self, request):
        owners = CustomUser.objects.filter(is_player=False)
        serializer = UserWithQuestionCountSerializer(owners, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)



class OwnerAllQuestionView(APIView):
    def get(self,request,username=None):
        questions = Question.objects.filter(user__username=username)
        serializer = QuestionSerializer(questions, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)