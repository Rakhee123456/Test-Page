// src/components/QuizCategorySelector.js

import React from 'react';

const QuizCategorySelector = ({ categories, onSelectCategory }) => {
  return (
    <div>
      <h2>Select a Quiz Category</h2>
      <select onChange={(e) => onSelectCategory(e.target.value)}>
        <option value="">Select a category</option>
        {categories.map((category, index) => (
          <option key={index} value={category}>
            {category}
          </option>
        ))}
      </select>
    </div>
  );
};

export default QuizCategorySelector;
