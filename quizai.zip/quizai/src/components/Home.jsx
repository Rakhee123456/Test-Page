import React, { useState, useEffect } from "react";
import QuizResult from "./QuizResult";
import QuizCategorySelector from "./QuizCategorySelector";
import QuizQuestion from "./QuizQuestion";
import {fetchQuizQuestions} from "../api"
const Home = () =>{
  const [categories] = useState([
    "Science",
    "History",
    "Math",
    "Geography",
    "Social Engineering",
  ]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState([]);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  useEffect(() => {
    if (selectedCategory) {
      const loadQuestions = async () => {
        const quizQuestions = await fetchQuizQuestions(selectedCategory);
        console.log("Fetched questions:", quizQuestions); // Add this line
        setQuestions(quizQuestions);
      };
      loadQuestions();
    }
  }, [selectedCategory]);

  const handleSelectCategory = (category) => {
    setSelectedCategory(category);
    setUserAnswers([]);
    setCurrentQuestionIndex(0);
    setScore(0);
    setQuizFinished(false);
  };

  const handleSelectAnswer = (answer) => {
    setUserAnswers([...userAnswers, answer]);
    if (answer === questions[currentQuestionIndex].answers[0]) {
      setScore(score + 1);
    }
    if (currentQuestionIndex + 1 < questions.length) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setQuizFinished(true);
    }
  };
  console.log(questions);
  return (
    <div>
      <h1>Quiz Website</h1>
      {!selectedCategory && (
        <QuizCategorySelector
          categories={categories}
          onSelectCategory={handleSelectCategory}
        />
      )}
      {/* <div>questions : {questions}</div> */}

      {/* {!selectedCategory && (
        <QuizCategorySelector
          categories={categories}
          onSelectCategory={handleSelectCategory}
        />
      )}
      {selectedCategory && !quizFinished && questions.length > 0 && (
        <>
          <div>Quiz Question</div>
          <QuizQuestion
            question={questions}
            // question={questions[currentQuestionIndex].question}
            options={questions[currentQuestionIndex].answers}
            onSelectAnswer={handleSelectAnswer}
          />
        </>
      )}
      {quizFinished && <QuizResult score={score} total={questions.length} />} */}
    </div>
  );
}

export default Home;