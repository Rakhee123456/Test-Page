// src/components/QuizResult.js

import React from 'react';

const QuizResult = ({ score, total }) => {
  return (
    <div>
      <h2>Your Score</h2>
      <p>
        You answered {score} out of {total} questions correctly.
      </p>
    </div>
  );
};

export default QuizResult;
