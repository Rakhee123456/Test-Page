// src/components/QuizQuestion.js

import React from 'react';

const QuizQuestion = ({ question, options, onSelectAnswer }) => {
    console.log("inside quiz question")
    console.log(question)
    console.log(options)
    console.log(onSelectAnswer)
    console.log("=================================")
    
  return (
    <div>
      <h3>{question}</h3>
      {options.map((option, index) => (
        <div key={index}>
          <input
            type="radio"
            id={`option-${index}`}
            name="quiz"
            value={option}
            onChange={() => onSelectAnswer(option)}
          />
          <label htmlFor={`option-${index}`}>{option}</label>
        </div>
      ))}
    </div>
  );
};

export default QuizQuestion;
